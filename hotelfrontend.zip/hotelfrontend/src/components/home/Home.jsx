import React from "react"
import MainHeader from "../layout/MainHeader"
import NavBar from "../layout/NavBar"
import HotelService from "../common/HotelService"
import Parallax from "../common/Parallax"
import RoomCarousel from "../common/RoomCarousel"
import RoomSearch from "../common/RoomSearch"
import { useLocation, Link } from "react-router-dom"
import { useAuth } from "../auth/AuthProvider"
import Logout from "../auth/Logout"
import bgImage from "../../assets/images/admin.webp";
import RoleList from "../roles/RoleList";
import UserList from "../roles/UserList";


const Home = () => {
	const location = useLocation()
	const message = location.state && location.state.message
	const { user } = useAuth()

	// Extract role name
	const userRole = user?.roles ? user.roles.toString().toUpperCase() : null

	return (
		<section>
			<>
					<MainHeader />
					<div className="container">
						{/* You can include RoomSearch if needed */}
						<RoomSearch />
						<RoomCarousel />
						<HotelService />
					</div>
				</>

			{/* 🌟 ADMIN SECTION */}
			
		</section>
	)
}

export default Home
